//
//  MusicCardsApp.swift
//  MusicCards
//
//  Created by Macbook on 14.02.2026.
//

import SwiftUI

@main
struct MusicCardsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
