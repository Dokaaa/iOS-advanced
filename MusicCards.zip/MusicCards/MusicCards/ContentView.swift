//
//  ContentView.swift
//  MusicCards
//

import SwiftUI

struct ContentView: View {
    
    
    let itemNames = [
        "Rock",
        "Pop",
        "Jazz",
        "Hip-Hop",
        "Classical",
        "Electronic"
    ]
    
    let itemIcons = [
        "guitars",
        "music.mic",
        "saxophone",
        "music.note.list",
        "pianokeys",
        "headphones"
    ]
    
    let itemDescriptions = [
        "Energetic music with electric guitars and strong drums.",
        "Catchy melodies popular worldwide.",
        "Smooth and relaxing instrumental music.",
        "Rhythmic beats with rap vocals.",
        "Calm orchestral compositions.",
        "Synth based futuristic dance music."
    ]
    
    
    let itemRatings = [5, 4, 3, 5, 2, 4]
    
    
    @State private var currentIndex = 0
    @State private var tapCount = 0
    
    
    var body: some View {
        VStack(spacing: 20) {
            
            // Icon
            Image(systemName: itemIcons[currentIndex])
                .font(.system(size: 80))
                .foregroundStyle(.purple)
            
            // Name
            Text(itemNames[currentIndex])
                .font(.title)
                .bold()
            
            Divider()
                .padding(.horizontal)
            
            // Description
            Text(itemDescriptions[currentIndex])
                .font(.body)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal)
            
            // Rating
            Text(ratingText())
                .font(.title2)
            
            // Button
            Button("Surprise Me!") {
                changeCard()
            }
            .buttonStyle(.borderedProminent)
            
            // Counter
            Text("Cards explored: \(tapCount)")
                .font(.footnote)
                .foregroundStyle(.gray)
        }
        .padding()
    }
    
    
    
    func ratingText() -> String {
        let rating = itemRatings[currentIndex]
        
        if rating == 0 {
            return "No energy"
        }
        
        return String(repeating: "⭐️", count: rating)
    }
    
    
    func changeCard() {
        var newIndex: Int
        
        repeat {
            newIndex = Int.random(in: 0..<itemNames.count)
        } while newIndex == currentIndex
        
        currentIndex = newIndex
        tapCount += 1
    }
}

#Preview {
    ContentView()
}
