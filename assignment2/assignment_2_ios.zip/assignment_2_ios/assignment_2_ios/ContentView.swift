import SwiftUI

// MARK: - Model
struct FavoriteItem: Identifiable {
    let id = UUID()
    let title: String
    let subtitle: String
    let emoji: String
    var rating: Int? = nil
    var isFavorite: Bool = false
}

// MARK: - Main View
struct ContentView: View {
    
    var body: some View {
        NavigationStack {
            ZStack {
                
                LinearGradient(
                    colors: [
                        Color.black,
                        Color.purple.opacity(0.9),
                        Color.black
                    ],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                .ignoresSafeArea()
                
                VStack(spacing: 35) {
                    
                    Spacer().frame(height: 40) // опускаем заголовок
                    
                    // ✨ Новый красивый заголовок
                    Text("My Favorites 💜")
                        .font(.system(size: 34, weight: .bold))
                        .foregroundColor(Color.gray.opacity(0.9))
                        .padding(.bottom, 20)
                    
                    NavigationLink(destination: CategoryView(title: "Music", items: music)) {
                        CategoryCard(title: "Music", emoji: "🎵")
                    }
                    
                    NavigationLink(destination: CategoryView(title: "Formula 1", items: f1Teams)) {
                        CategoryCard(title: "Formula 1", emoji: "🏎")
                    }
                    
                    NavigationLink(destination: CategoryView(title: "Food", items: food)) {
                        CategoryCard(title: "Food", emoji: "🍜")
                    }
                    
                    NavigationLink(destination: CategoryView(title: "Movies", items: movies)) {
                        CategoryCard(title: "Movies", emoji: "🎬")
                    }
                    
                    Spacer()
                }
                .padding(.horizontal, 24)
            }
        }
    }
    
    // MARK: - Data
    
    private var music: [FavoriteItem] = [
        FavoriteItem(title: "RAYE", subtitle: "Where The Hell Is My Husband?", emoji: "🎤"),
        FavoriteItem(title: "The Weeknd", subtitle: "R&B / Pop", emoji: "🌙"),
        FavoriteItem(title: "SZA", subtitle: "R&B", emoji: "💫"),
        FavoriteItem(title: "Tyla", subtitle: "Pop / Afrobeat", emoji: "🔥"),
        FavoriteItem(title: "Doja Cat", subtitle: "Pop / Rap", emoji: "🎧"),
        FavoriteItem(title: "Billie Eilish", subtitle: "Alt Pop", emoji: "🖤"),
        FavoriteItem(title: "Sadraddin", subtitle: "Kazakhstan Pop", emoji: "🇰🇿"),
        FavoriteItem(title: "Ninety One", subtitle: "Q-pop", emoji: "🎶"),
        FavoriteItem(title: "Moldanazar", subtitle: "Indie", emoji: "🎹"),
        FavoriteItem(title: "Adele", subtitle: "Soul / Pop", emoji: "🎙")
    ]
    
    private var f1Teams: [FavoriteItem] = [
        FavoriteItem(title: "Red Bull Racing", subtitle: "Your #1 Team", emoji: "🐂", rating: 1),
        FavoriteItem(title: "Mercedes", subtitle: "Silver Arrows", emoji: "⭐️", rating: 2),
        FavoriteItem(title: "McLaren", subtitle: "Papaya Team", emoji: "🧡", rating: 3),
        FavoriteItem(title: "Williams", subtitle: "Historic Team", emoji: "💙", rating: 4),
        FavoriteItem(title: "Ferrari", subtitle: "Scuderia", emoji: "🔴", rating: 5),
        FavoriteItem(title: "Aston Martin", subtitle: "British Racing", emoji: "💚", rating: 6),
        FavoriteItem(title: "Alpine", subtitle: "French Team", emoji: "🇫🇷", rating: 7),
        FavoriteItem(title: "RB", subtitle: "Junior Red Bull", emoji: "⚡️", rating: 8),
        FavoriteItem(title: "Kick Sauber", subtitle: "Swiss Team", emoji: "🟢", rating: 9),
        FavoriteItem(title: "Haas", subtitle: "American Team", emoji: "🇺🇸", rating: 10)
    ]
    
    private var food: [FavoriteItem] = [
        FavoriteItem(title: "Pizza", subtitle: "Italian", emoji: "🍕"),
        FavoriteItem(title: "Sushi", subtitle: "Japanese", emoji: "🍣"),
        FavoriteItem(title: "Lagman", subtitle: "Central Asian", emoji: "🍜"),
        FavoriteItem(title: "Beshbarmak", subtitle: "Kazakh Traditional", emoji: "🥩"),
        FavoriteItem(title: "Burgers", subtitle: "Street Food", emoji: "🍔"),
        FavoriteItem(title: "Pasta", subtitle: "Alfredo", emoji: "🍝"),
        FavoriteItem(title: "Tiramisu", subtitle: "Dessert", emoji: "🍰"),
        FavoriteItem(title: "Ice Cream", subtitle: "Sweet", emoji: "🍨"),
        FavoriteItem(title: "Steak", subtitle: "Medium Rare", emoji: "🥩"),
        FavoriteItem(title: "Croissant", subtitle: "French Pastry", emoji: "🥐")
    ]
    
    private var movies: [FavoriteItem] = [
        FavoriteItem(title: "Interstellar", subtitle: "Sci-Fi", emoji: "🚀"),
        FavoriteItem(title: "Inception", subtitle: "Sci-Fi", emoji: "🌀"),
        FavoriteItem(title: "The Dark Knight", subtitle: "Action", emoji: "🦇"),
        FavoriteItem(title: "La La Land", subtitle: "Drama", emoji: "🎹"),
        FavoriteItem(title: "The Wolf of Wall Street", subtitle: "Drama", emoji: "💰"),
        FavoriteItem(title: "The Intouchables", subtitle: "Comedy", emoji: "🤝"),
        FavoriteItem(title: "Avatar", subtitle: "Sci-Fi", emoji: "🌍"),
        FavoriteItem(title: "The Social Network", subtitle: "Biography", emoji: "💻"),
        FavoriteItem(title: "Coco", subtitle: "Animation", emoji: "🎸"),
        FavoriteItem(title: "Oppenheimer", subtitle: "Drama", emoji: "💣")
    ]
}

// MARK: - Category Screen
struct CategoryView: View {
    let title: String
    @State var items: [FavoriteItem]
    
    var body: some View {
        ZStack {
            LinearGradient(
                colors: [
                    Color.black,
                    Color.purple.opacity(0.8),
                    Color.black
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            
            List {
                ForEach($items) { $item in
                    ItemRow(item: $item)
                }
            }
            .scrollContentBackground(.hidden)
            .listStyle(.plain)
        }
        .navigationTitle(title)
    }
}

// MARK: - Item Row
struct ItemRow: View {
    @Binding var item: FavoriteItem
    
    var body: some View {
        HStack {
            Text(item.emoji)
                .font(.largeTitle)
            
            VStack(alignment: .leading) {
                Text(item.title)
                    .foregroundColor(.white)
                    .fontWeight(.semibold)
                
                Text(item.subtitle)
                    .foregroundColor(.gray)
                    .font(.subheadline)
                
                if let rating = item.rating {
                    Text("Rank: \(rating)")
                        .foregroundColor(.purple)
                        .font(.caption)
                }
            }
            
            Spacer()
            
            Button {
                item.isFavorite.toggle()
            } label: {
                Image(systemName: item.isFavorite ? "heart.fill" : "heart")
                    .foregroundColor(.purple)
            }
        }
        .padding()
        .background(Color.black.opacity(0.7))
        .cornerRadius(15)
        .listRowBackground(Color.clear)
        .padding(.vertical, 6)
    }
}

// MARK: - Category Card
struct CategoryCard: View {
    let title: String
    let emoji: String
    
    var body: some View {
        HStack {
            Text(emoji)
                .font(.largeTitle)
            
            Text(title)
                .font(.title2)
                .fontWeight(.bold)
                .foregroundColor(.white)
            
            Spacer()
            
            Image(systemName: "arrow.right")
                .foregroundColor(.purple)
                .font(.title3)
        }
        .padding()
        .frame(maxWidth: .infinity)
        .background(
            LinearGradient(
                colors: [
                    Color.purple.opacity(0.5),
                    Color.black.opacity(0.8)
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        )
        .cornerRadius(25)
        .shadow(color: .purple.opacity(0.6), radius: 12)
    }
}

#Preview {
    ContentView()
}
