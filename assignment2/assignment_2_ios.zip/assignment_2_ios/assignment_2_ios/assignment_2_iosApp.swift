//
//  assignment_2_iosApp.swift
//  assignment_2_ios
//
//  Created by Macbook on 27.02.2026.
//

import SwiftUI

@main
struct assignment_2_iosApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
