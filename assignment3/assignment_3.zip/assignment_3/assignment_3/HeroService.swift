import Foundation

class HeroService {
    
    func fetchHero(id: Int) async throws -> Hero {
        
        let urlString = "https://akabab.github.io/superhero-api/api/id/\(id).json"
        
        guard let url = URL(string: urlString) else {
            throw URLError(.badURL)
        }
        
        let (data, _) = try await URLSession.shared.data(from: url)
        
        let decoder = JSONDecoder()
        
        let hero = try decoder.decode(Hero.self, from: data)
        
        return hero
    }
}
