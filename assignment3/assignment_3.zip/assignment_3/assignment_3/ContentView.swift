import SwiftUI

struct ContentView: View {
    
    @StateObject private var viewModel = HeroViewModel()
    
    var body: some View {
        
        ScrollView {
            
            VStack(spacing: 20) {
                
                if viewModel.isLoading {
                    ProgressView("Loading hero...")
                }
                
                if let error = viewModel.errorMessage {
                    Text(error)
                        .foregroundColor(.red)
                }
                
                if let hero = viewModel.hero {
                    
                    VStack(spacing: 16) {
                        
                        AsyncImage(url: URL(string: hero.images.lg)) { phase in
                            
                            switch phase {
                                
                            case .success(let image):
                                image
                                    .resizable()
                                    .scaledToFit()
                                    .frame(height: 300)
                                
                            case .failure(_):
                                Text("Image failed to load")
                                
                            default:
                                ProgressView()
                            }
                        }
                        
                        Text(hero.name)
                            .font(.largeTitle)
                            .bold()
                        
                        Divider()
                        
                        // POWERSTATS
                        VStack(alignment: .leading, spacing: 8) {
                            
                            Text("Powerstats")
                                .font(.headline)
                            
                            StatBar(title: "Intelligence", value: hero.powerstats.intelligence)
                            StatBar(title: "Strength", value: hero.powerstats.strength)
                            StatBar(title: "Speed", value: hero.powerstats.speed)
                            StatBar(title: "Durability", value: hero.powerstats.durability)
                            StatBar(title: "Power", value: hero.powerstats.power)
                            StatBar(title: "Combat", value: hero.powerstats.combat)
                        }
                        
                        Divider()
                        
                        VStack(alignment: .leading, spacing: 6) {
                            
                            Text("Details")
                                .font(.headline)
                            
                            Text("Full Name: \(hero.biography.fullName ?? "Unknown")")
                            Text("Gender: \(hero.appearance.gender ?? "Unknown")")
                            Text("Race: \(hero.appearance.race ?? "Unknown")")
                            Text("Publisher: \(hero.biography.publisher ?? "Unknown")")
                            Text("Alignment: \(hero.biography.alignment ?? "Unknown")")
                            Text("Occupation: \(hero.work.occupation ?? "Unknown")")
                            Text("Eye Color: \(hero.appearance.eyeColor ?? "Unknown")")
                            Text("Hair Color: \(hero.appearance.hairColor ?? "Unknown")")
                        }
                    }
                    .padding()
                }
                
                Button {
                    Task {
                        await viewModel.fetchRandomHero()
                    }
                } label: {
                    Text("Randomize Hero")
                        .font(.headline)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }
                .padding()
            }
        }
    }
}
#Preview {
    ContentView()
}
