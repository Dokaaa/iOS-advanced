import SwiftUI

struct StatBar: View {
    
    let title: String
    let value: Int
    
    var body: some View {
        
        VStack(alignment: .leading) {
            
            Text("\(title): \(value)")
            
            ProgressView(value: Double(value), total: 100)
        }
    }
}
