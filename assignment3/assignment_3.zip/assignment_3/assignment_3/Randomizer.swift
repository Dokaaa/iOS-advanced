import SwiftUI

@main
struct RandomizerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
