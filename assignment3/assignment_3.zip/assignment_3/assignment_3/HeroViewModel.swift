import Foundation
import SwiftUI

@MainActor
class HeroViewModel: ObservableObject {
    
    @Published var hero: Hero?
    @Published var isLoading = false
    @Published var errorMessage: String?
    
    private let service = HeroService()
    
    func fetchRandomHero() async {
        
        isLoading = true
        errorMessage = nil
        
        let randomID = Int.random(in: 1...731)
        
        do {
            hero = try await service.fetchHero(id: randomID)
        } catch {
            errorMessage = "Failed to load hero. Check your internet connection."
        }
        
        isLoading = false
    }
}
